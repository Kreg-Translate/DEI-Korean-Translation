import { hash } from './scan.mjs';

export const LABELS = { untranslated:'미번역', existing:'기존 DEI 번역', base:'기본 패치 참고', draft:'작업 중', reviewed:'검수 완료', exempt:'번역 불필요', blank:'빈 원문', stale:'원문 변경' };
export function effective(e, edits) {
  const edit = edits[e.key];
  const selected = edit && e.variants.find(v => hash(v.text) === edit.sourceHash);
  return { ...e, source: selected?.text ?? e.source, sourceHash: selected ? edit.sourceHash : e.sourceHash,
    status: edit ? selected ? edit.status : 'stale' : e.initial,
    translation: edit?.text ?? e.candidate, note: edit?.note || '', revision: edit?.revision || 0,
    selectedSource: !!selected, history: edit?.history || [] };
}
export function qa(source, translation, glossary = []) {
  const issues = [];
  // Consume escaped percent signs and Total War's numeric placeholders before
  // printf formats, so the literal text "%% 1st" cannot be parsed as "% 1s".
  const tokens = s => (s.match(/\[\[[\s\S]*?\]\]|\{\{[^{}]+\}\}|\{[A-Za-z0-9_:.]+\}|%%|%[-+]?n|%(?:\d+\$)?[-+0 #]*\d*(?:\.\d+)?[sdfiu]|%\d+|\\n/g) || []).sort();
  const a=tokens(source), b=tokens(translation);
  if (JSON.stringify(a) !== JSON.stringify(b)) issues.push({level:'error', text:'원문의 서식 태그·치환 변수·\\n 구성이 번역과 다릅니다.'});
  if (!translation.trim()) issues.push({level:'error',text:'번역문이 비어 있습니다.'});
  if (translation.length > 65535 || translation.includes('\0')) issues.push({level:'error',text:'게임 문자열 형식에 맞지 않습니다.'});
  const nums = s => (s.replace(/\[\[[\s\S]*?\]\]/g,'').match(/\d+(?:[.,]\d+)*%?/g) || []).sort().join('|');
  if (nums(source) !== nums(translation)) issues.push({level:'warning',text:'숫자 또는 백분율이 원문과 다릅니다. 의도한 번역인지 확인하세요.'});
  if ((source.match(/\n/g)||[]).length !== (translation.match(/\n/g)||[]).length) issues.push({level:'warning',text:'줄바꿈 수가 원문과 다릅니다.'});
  for (const t of glossary) if (source.toLowerCase().includes(t.en.toLowerCase()) && !translation.includes(t.ko)) issues.push({level:'warning',text:`확정 용어 확인: ${t.en} → ${t.ko}`});
  return issues;
}
export function summary(dataset, edits) {
  const counts={}, categories={}, files={}; let conflicts=0;
  for (const raw of dataset.entries) {
    const e=effective(raw,edits); counts[e.status]=(counts[e.status]||0)+1;
    const c=categories[e.category] ||= {total:0,existing:0,reviewed:0}; c.total++;
    if (e.status==='existing') c.existing++;
    if (['reviewed','exempt'].includes(e.status)) c.reviewed++;
    for (const f of new Set(e.variants.map(v=>v.file))) files[f]=(files[f]||0)+1;
    if (e.sourceConflict || e.translationConflict) conflicts++;
  }
  const target=dataset.entries.filter(e=>e.initial!=='blank').length;
  const completed=dataset.entries.filter(e=>e.initial!=='blank'&&['reviewed','exempt'].includes(effective(e,edits).status)).length;
  return { counts,categories,files,target,completed,percent:target?100*completed/target:0,conflicts,report:dataset.report };
}

export function makeTerms(dataset) {
  const terms = new Map();
  for (const e of dataset.entries) {
    if (e.initial!=='existing' || e.sourceConflict || e.translationConflict || e.source.length>65 || e.candidate.length>65 || /\n|\[\[|[.!?]$/.test(e.source) || e.source.split(/\s+/).length>7) continue;
    const id=e.source+'\0'+e.candidate;
    if (!terms.has(id)) terms.set(id,{en:e.source,ko:e.candidate,key:e.key,category:e.category,count:0});
    terms.get(id).count++;
  }
  return [...terms.values()].sort((a,b)=>b.count-a.count||a.en.localeCompare(b.en));
}
