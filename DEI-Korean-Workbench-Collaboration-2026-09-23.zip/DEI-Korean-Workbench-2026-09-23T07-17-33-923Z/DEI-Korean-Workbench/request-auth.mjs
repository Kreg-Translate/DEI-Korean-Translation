export function acceptsWrite(headers, token, address) {
  if(headers['x-workbench-token']===token)return true;
  // An already-open editor can outlive a local server restart. Preserve its
  // ability to save unsaved work only when the browser proves same-origin.
  return headers.origin===address && headers['sec-fetch-site']==='same-origin'
    && /^[a-f0-9]{48}$/.test(headers['x-workbench-token']||'');
}
