#!/bin/bash
source "$(dirname -- "$0")/runtime.sh"
"$NODE_BIN" "$WORKBENCH_ROOT/launch.mjs" || workbench_error '실행하지 못했습니다. data/server.log를 확인하세요.'
if [ "${DEI_NO_BROWSER:-0}" != "1" ]; then
  open "http://127.0.0.1:${DEI_PORT:-3219}/" || workbench_error '브라우저에서 http://127.0.0.1:3219/ 를 열어주세요.'
fi
printf '\n작업실을 시작했습니다. 이 터미널 창은 닫아도 됩니다.\n종료하려면 Stop.command를 실행하세요.\n'
