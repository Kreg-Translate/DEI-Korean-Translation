@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or later is required.
  pause
  exit /b 1
)
node launch.mjs
if errorlevel 1 (
  pause
  exit /b 1
)
start "" "http://127.0.0.1:3219/"
