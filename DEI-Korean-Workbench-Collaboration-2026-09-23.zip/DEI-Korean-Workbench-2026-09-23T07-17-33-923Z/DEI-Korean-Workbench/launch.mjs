import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const url='http://127.0.0.1:3219/api/summary';
function running(){return new Promise(resolve=>{const r=http.get(url,res=>{let body='';res.on('data',x=>body+=x);res.on('end',()=>{try{resolve(!!JSON.parse(body).report?.inventory);}catch{resolve(false);}});});r.on('error',()=>resolve(false));r.setTimeout(1500,()=>{r.destroy();resolve(false);});});}
if(!await running()) {
  fs.mkdirSync(path.join(root,'data'),{recursive:true});
  const log=fs.openSync(path.join(root,'data/server.log'),'a');
  const child=spawn(process.execPath,[path.join(root,'server.mjs')],{cwd:root,detached:true,windowsHide:true,stdio:['ignore',log,log]});
  child.unref();fs.closeSync(log);
  let ok=false;for(let i=0;i<30;i++){if(await running()){ok=true;break;}await new Promise(r=>setTimeout(r,300));}
  if(!ok){console.error('Could not start the workbench. See data/server.log.');process.exit(1);}
}
console.log('http://127.0.0.1:3219/');
