import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

export function resolvePackPath(value,{root,home=os.homedir(),pathApi=path}={}){
  if(typeof value!=='string'||!value.trim())throw Error('모드 파일 경로가 비어 있습니다.');
  const expanded=value==='~'?home:value.startsWith('~/')||value.startsWith('~\\')?pathApi.join(home,value.slice(2)):value;
  return pathApi.isAbsolute(expanded)?pathApi.normalize(expanded):pathApi.resolve(root,expanded);
}
export function readPackConfig(root){
  const config=JSON.parse(fs.readFileSync(path.join(root,'config.json'),'utf8').replace(/^\uFEFF/,''));
  const localFile=path.join(root,'config.local.json');
  const local=fs.existsSync(localFile)?JSON.parse(fs.readFileSync(localFile,'utf8').replace(/^\uFEFF/,'')):{};
  if(local.paths!==undefined&&(!local.paths||typeof local.paths!=='object'||Array.isArray(local.paths)))throw Error('config.local.json의 paths 형식을 확인하세요.');
  return{...config,packs:config.packs.map(pack=>({...pack,path:resolvePackPath(local.paths?.[pack.label]??pack.path,{root})}))};
}
