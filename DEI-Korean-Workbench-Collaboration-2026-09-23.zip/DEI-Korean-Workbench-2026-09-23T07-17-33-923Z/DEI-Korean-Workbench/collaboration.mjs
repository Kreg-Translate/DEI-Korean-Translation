import crypto from 'node:crypto';
import {hash} from './scan.mjs';
import {qa} from './model.mjs';

const fail=message=>{const error=new Error(message);error.status=400;throw error;};
const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const canonical=x=>JSON.stringify(x,(_,v)=>object(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const equal=(a,b)=>canonical(a)===canonical(b);
const content=e=>e?{text:e.text,note:e.note||'',status:e.status,sourceHash:e.sourceHash}:null;
const term=t=>t?{en:t.en,ko:t.ko,note:t.note||''}:null;
export const stateToken=state=>hash(canonical(state));
function validateEdit(e,nullable=false){
  if(e===null&&nullable)return;
  if(!object(e)||typeof e.text!=='string'||e.text.length>65535||e.text.includes('\0')||!['draft','reviewed','exempt'].includes(e.status)||typeof e.sourceHash!=='string'||!/^[a-f0-9]{64}$/.test(e.sourceHash)||typeof(e.note??'')!=='string'||(e.note||'').length>20000)fail('공동작업 파일의 번역 형식을 확인하세요.');
}
function validateTerm(t,nullable=false){
  if(t===null&&nullable)return;
  if(!object(t)||typeof t.en!=='string'||!t.en.trim()||t.en.length>150||typeof t.ko!=='string'||!t.ko.trim()||t.ko.length>150||typeof(t.note??'')!=='string'||(t.note||'').length>2000)fail('공동작업 파일의 용어 형식을 확인하세요.');
}
function termMap(terms){
  if(!Array.isArray(terms))fail('용어장 배열이 필요합니다.');
  const map=new Map();for(const t of terms){validateTerm(t);if(map.has(t.en))fail('중복 용어가 있습니다.');map.set(t.en,term(t));}return map;
}
const basePayload=base=>({edits:base.edits,glossary:base.glossary});
export function makeBase(state){
  const payload={edits:state.edits,glossary:state.glossary};
  return{format:'dei-collaboration-base',version:1,id:hash(canonical(payload)),createdAt:new Date().toISOString(),...payload};
}
export function makeChanges(base,state,author){
  if(!object(base)||base.format!=='dei-collaboration-base'||base.version!==1||!object(base.edits)||base.id!==hash(canonical(basePayload(base))))fail('공동작업 기준본 파일을 선택하세요. 기준본을 직접 수정하면 사용할 수 없습니다.');
  if(typeof author!=='string'||!author.trim()||author.length>80)fail('작업자 이름을 입력하세요 (80자 이내).');
  for(const e of Object.values(base.edits))validateEdit(e);
  const changes=[];
  for(const key of [...new Set([...Object.keys(base.edits),...Object.keys(state.edits)])].sort()){
    const before=content(base.edits[key]),after=content(state.edits[key]);
    if(equal(before,after))continue;
    if(!after)fail('기준본에 있던 번역이 현재 저장본에서 사라졌습니다. 올바른 기준본인지 확인하세요.');
    validateEdit(after);changes.push({key,before,after});
  }
  const bm=termMap(base.glossary),cm=termMap(state.glossary),glossary=[];
  for(const en of [...new Set([...bm.keys(),...cm.keys()])].sort()){
    const before=bm.get(en)||null,after=cm.get(en)||null;if(!equal(before,after))glossary.push({en,before,after});
  }
  return{format:'dei-collaboration-changes',version:1,id:crypto.randomUUID(),baseId:base.id,author:author.trim(),createdAt:new Date().toISOString(),changes,glossary};
}
function checkPacket(packet){
  if(!object(packet)||packet.format!=='dei-collaboration-changes'||packet.version!==1||typeof packet.baseId!=='string'||!/^[a-f0-9]{64}$/.test(packet.baseId)||typeof packet.id!=='string'||packet.id.length>100||typeof packet.author!=='string'||!packet.author.trim()||packet.author.length>80||!Array.isArray(packet.changes)||!Array.isArray(packet.glossary)||packet.changes.length>50000||packet.glossary.length>50000)fail('공동작업 변경 파일을 선택하세요.');
  const keys=new Set();for(const r of packet.changes){
    if(!object(r)||typeof r.key!=='string'||!r.key||r.key.length>1000||keys.has(r.key))fail('중복되거나 잘못된 번역 키입니다.');
    keys.add(r.key);validateEdit(r.before,true);validateEdit(r.after);
  }
  const terms=new Set();for(const r of packet.glossary){
    if(!object(r)||typeof r.en!=='string'||terms.has(r.en))fail('중복되거나 잘못된 용어 키입니다.');
    terms.add(r.en);validateTerm(r.before,true);validateTerm(r.after,true);
    if(!r.before&&!r.after||r.before&&r.before.en!==r.en||r.after&&r.after.en!==r.en)fail('용어 키가 일치하지 않습니다.');
  }
}
const disposition=(before,local,incoming)=>equal(local,incoming)?'same':equal(before,incoming)?'keep':equal(local,before)?'apply':'conflict';
export function previewChanges(packet,state,byKey){
  checkPacket(packet);const rows=[];
  for(const r of packet.changes){
    const raw=byKey.get(r.key),local=content(state.edits[r.key]),variant=raw?.variants.find(v=>hash(v.text)===r.after.sourceHash);
    let error='';if(!raw)error='현재 모드에 없는 키입니다.';else if(!variant)error='원문이 다릅니다. 같은 모드 버전인지 확인하세요.';
    const issues=variant?qa(variant.text,r.after.text,state.glossary):[];
    if(r.after.status==='reviewed'&&issues.some(i=>i.level==='error'))error='검수 완료 번역의 서식 오류를 먼저 수정해야 합니다.';
    if(r.after.status==='exempt'&&variant&&r.after.text!==variant.text)error='번역 불필요 항목은 원문과 같아야 합니다.';
    rows.push({id:'entry:'+r.key,kind:'entry',key:r.key,source:variant?.text||raw?.source||'',before:content(r.before),local,incoming:content(r.after),action:error?'blocked':disposition(content(r.before),local,content(r.after)),error,issues});
  }
  const tm=termMap(state.glossary);
  for(const r of packet.glossary){const local=tm.get(r.en)||null;rows.push({id:'term:'+r.en,kind:'term',key:r.en,before:term(r.before),local,incoming:term(r.after),action:disposition(term(r.before),local,term(r.after)),error:'',issues:[]});}
  const counts={apply:0,conflict:0,same:0,keep:0,blocked:0};for(const r of rows)counts[r.action]++;
  return{stateToken:stateToken(state),author:packet.author,baseId:packet.baseId,counts,rows};
}
export function mergeChanges(packet,state,byKey,expectedToken,choices={}){
  if(expectedToken!==stateToken(state))fail('미리보기 이후 작업이 변경되었습니다. 다시 비교하세요.');
  const preview=previewChanges(packet,state,byKey);
  if(!object(choices))fail('충돌 선택 형식을 확인하세요.');
  const edits={...state.edits},terms=termMap(state.glossary);let applied=0,kept=0;
  for(const row of preview.rows){
    let action=row.action;
    if(action==='conflict'||action==='blocked'){
      const choice=choices[row.id];
      if(!['local','incoming'].includes(choice))fail('충돌 또는 원문 불일치 항목을 모두 선택하세요.');
      if(action==='blocked'&&choice==='incoming')fail(row.error);
      action=choice==='incoming'?'apply':'keep';
    }
    if(action!=='apply'){kept++;continue;}
    if(row.kind==='entry'){
      const old=edits[row.key];
      edits[row.key]={...row.incoming,revision:(old?.revision||0)+1,updatedAt:new Date().toISOString(),history:[...(old?.history||[]),...(old?[{...content(old),updatedAt:old.updatedAt}]:[])].slice(-12)};
    }else if(row.incoming)terms.set(row.key,row.incoming);else terms.delete(row.key);
    applied++;
  }
  return{state:{...state,edits,glossary:[...terms.values()]},applied,kept,preview};
}
