import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
if(Number(process.versions.node.split('.')[0])<22){console.error('Node.js 22 or later is required.');process.exit(1);}
const port=Number(process.env.DEI_PORT||3219);
if(!Number.isInteger(port)||port<1||port>65535){console.error('Invalid DEI_PORT.');process.exit(1);}
const address=`http://127.0.0.1:${port}`;
const url=address+'/api/summary';
function running(){return new Promise(resolve=>{const r=http.get(url,res=>{let body='';res.on('data',x=>body+=x);res.on('end',()=>{try{resolve(!!JSON.parse(body).report?.inventory);}catch{resolve(false);}});});r.on('error',()=>resolve(false));r.setTimeout(1500,()=>{r.destroy();resolve(false);});});}
if(!await running()) {
  fs.mkdirSync(path.join(root,'data'),{recursive:true});
  const log=fs.openSync(path.join(root,'data/server.log'),'a');
  const child=spawn(process.execPath,[path.join(root,'server.mjs')],{cwd:root,detached:true,windowsHide:true,stdio:['ignore',log,log]});
  child.on('error',error=>console.error('Could not start: '+error.message));
  child.unref();fs.closeSync(log);
  let ok=false;for(let i=0;i<30;i++){if(await running()){ok=true;break;}await new Promise(r=>setTimeout(r,300));}
  if(!ok){console.error('Could not start the workbench. See data/server.log.');process.exit(1);}
}
console.log(address);
