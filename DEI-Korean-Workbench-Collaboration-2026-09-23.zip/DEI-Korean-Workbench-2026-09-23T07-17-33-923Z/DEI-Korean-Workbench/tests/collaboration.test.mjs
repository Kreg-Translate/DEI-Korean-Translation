import {test} from 'node:test';
import assert from 'node:assert/strict';
import {makeBase,makeChanges,previewChanges,mergeChanges} from '../collaboration.mjs';
import {hash} from '../scan.mjs';
const edit=(text,status='draft',source='Source')=>({text,status,sourceHash:hash(source),note:'',revision:1,updatedAt:'2026-01-01',history:[]});
const state=(edits={},glossary=[])=>({version:1,edits,glossary});
const byKey=new Map(['a','b','c'].map(key=>[key,{key,source:'Source',variants:[{text:'Source'}]}]));
const preview=(packet,s)=>previewChanges(packet,s,byKey);
const merge=(packet,s,choices={})=>mergeChanges(packet,s,byKey,preview(packet,s).stateToken,choices);

test('Different entries merge and reviewed status, notes, glossary and unrelated history survive',()=>{
  const base=makeBase(state());const friend=state({a:{...edit('친구 번역','reviewed'),note:'검토 완료'}},[{en:'Source',ko:'원문',note:'공통 용어'}]);
  const packet=makeChanges(base,friend,'친구');const local=state({b:edit('내 번역')});const snapshot=structuredClone(local);
  const result=merge(packet,local);assert.equal(result.applied,2);assert.equal(result.state.edits.a.status,'reviewed');assert.equal(result.state.edits.a.note,'검토 완료');assert.deepEqual(result.state.edits.b,local.edits.b);assert.deepEqual(result.state.glossary,friend.glossary);assert.deepEqual(local,snapshot);
  assert.equal(merge(packet,result.state).applied,0);
});
test('Two different edits require an explicit choice and keep prior history',()=>{
  const original=state({a:edit('기준')});const packet=makeChanges(makeBase(original),state({a:edit('친구')}),'친구');const local=state({a:{...edit('내 번역','reviewed'),revision:7}});
  assert.equal(preview(packet,local).counts.conflict,1);assert.throws(()=>merge(packet,local),/모두 선택/);
  assert.deepEqual(merge(packet,local,{'entry:a':'local'}).state,local);
  const result=merge(packet,local,{'entry:a':'incoming'});assert.equal(result.state.edits.a.text,'친구');assert.equal(result.state.edits.a.revision,8);assert.equal(result.state.edits.a.history.at(-1).status,'reviewed');
});
test('A review-only change conflicts with a changed draft and never silently downgrades a review',()=>{
  const base=state({a:edit('같은 번역')});const packet=makeChanges(makeBase(base),state({a:edit('다른 초안')}),'친구');const local=state({a:edit('같은 번역','reviewed')});assert.equal(preview(packet,local).counts.conflict,1);assert.throws(()=>merge(packet,local));
});
test('Concurrent save invalidates the entire preview, including glossary updates',()=>{
  const packet=makeChanges(makeBase(state()),state({a:edit('친구')}),'친구');const local=state();const p=preview(packet,local);local.glossary.push({en:'word',ko:'단어'});assert.throws(()=>mergeChanges(packet,local,byKey,p.stateToken),/다시 비교/);assert.deepEqual(local.edits,{});
});
test('Different source, unknown key, malformed reviewed markup, and invalid exemption are blocked',()=>{
  for(const [key,incoming] of [['a',edit('번역','draft','different')],['unknown',edit('번역')],['a',edit('다름','exempt')]]){
    const packet=makeChanges(makeBase(state()),state({[key]:incoming}),'친구');const p=preview(packet,state());assert.equal(p.counts.blocked,1);assert.throws(()=>merge(packet,state(),{['entry:'+key]:'incoming'}));assert.equal(merge(packet,state(),{['entry:'+key]:'local'}).applied,0);
  }
  const keys=new Map([['a',{source:'%d',variants:[{text:'%d'}]}]]);const packet=makeChanges(makeBase(state()),state({a:edit('누락','reviewed','%d')}),'친구');assert.equal(previewChanges(packet,state(),keys).counts.blocked,1);
});
test('Glossary deletions merge, and conflicting edits or deletions require selection',()=>{
  const original=state({},[{en:'word',ko:'단어',note:''}]);const packet=makeChanges(makeBase(original),state(),'친구');assert.deepEqual(merge(packet,original).state.glossary,[]);
  const local=state({},[{en:'word',ko:'용어',note:''}]);assert.equal(preview(packet,local).counts.conflict,1);assert.throws(()=>merge(packet,local));assert.deepEqual(merge(packet,local,{'term:word':'local'}).state.glossary,local.glossary);
});
test('Malformed bases and duplicate keys are rejected; export includes semantic changes only',()=>{
  const original=state({a:edit('원래')});const base=makeBase(original);const local=structuredClone(original);local.edits.a.revision++;local.edits.a.updatedAt='later';assert.equal(makeChanges(base,local,'나').changes.length,0);
  const bad=structuredClone(base);bad.edits.a.text='조작';assert.throws(()=>makeChanges(bad,local,'나'));
  const packet=makeChanges(makeBase(state()),original,'친구');packet.changes.push(packet.changes[0]);assert.throws(()=>preview(packet,state()),/중복/);
});
