export async function readJsonBody(stream, maxBytes=16_000_000) {
  const chunks=[];let bytes=0;
  for await(const part of stream){
    const chunk=Buffer.isBuffer(part)?part:Buffer.from(part);
    bytes+=chunk.length;
    if(bytes>maxBytes){const e=new Error('입력 파일이 너무 큽니다.');e.status=413;throw e;}
    chunks.push(chunk);
  }
  // A network chunk can end in the middle of a Korean UTF-8 character.
  // Decode only after joining the bytes, so chunk boundaries cannot alter text.
  try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
  catch{const e=new Error('JSON 형식을 확인하세요.');e.status=400;throw e;}
}
