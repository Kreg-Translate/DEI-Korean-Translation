#!/bin/bash
# Shared by the macOS launchers. Compatible with the system Bash 3.2.
WORKBENCH_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)" || exit 1
cd "$WORKBENCH_ROOT" || exit 1
NODE_BIN="${DEI_NODE:-}"
if [ -z "$NODE_BIN" ]; then
  NODE_BIN="$(command -v node 2>/dev/null || true)"
fi
if [ -z "$NODE_BIN" ]; then
  for candidate in /opt/homebrew/bin/node /usr/local/bin/node; do
    if [ -x "$candidate" ]; then NODE_BIN="$candidate"; break; fi
  done
fi
workbench_error() {
  printf '\n%s\n' "$1" >&2
  if [ -t 0 ]; then read -r -p 'Press Return to close. ' _reply; fi
  exit 1
}
if [ -z "$NODE_BIN" ] || [ ! -x "$NODE_BIN" ]; then
  workbench_error 'Node.js 22 이상을 설치하세요: https://nodejs.org/en/download (Apple Silicon: macOS ARM64)'
fi
if ! "$NODE_BIN" -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)'; then
  workbench_error 'Node.js 22 이상이 필요합니다. 설치 후 다시 실행하세요.'
fi
