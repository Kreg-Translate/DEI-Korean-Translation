import fs from 'node:fs';

function readAt(fd, size, position) {
  const b = Buffer.alloc(size);
  if (fs.readSync(fd, b, 0, size, position) !== size) throw new Error('Unexpected end of pack');
  return b;
}

export function readPack(file) {
  const fd = fs.openSync(file, 'r');
  try {
    const h = readAt(fd, 28, 0);
    if (h.toString('ascii', 0, 4) !== 'PFH4') throw new Error('Only PFH4 packs are supported');
    const flags = h.readUInt32LE(4);
    if (flags & ~0x4f) throw new Error(`Unsupported PFH4 flags: ${flags}`);
    const depCount = h.readUInt32LE(8), depSize = h.readUInt32LE(12), count = h.readUInt32LE(16), idxSize = h.readUInt32LE(20);
    const dep = readAt(fd, depSize, 28).toString('utf8').split('\0').filter(Boolean);
    if (dep.length !== depCount) throw new Error('Dependency index mismatch');
    const idx = readAt(fd, idxSize, 28 + depSize), entries = [];
    let p = 0, offset = 28 + depSize + idxSize;
    for (let i = 0; i < count; i++) {
      const size = idx.readUInt32LE(p); p += 4;
      if (flags & 64) p += 4;
      const end = idx.indexOf(0, p);
      if (end < p) throw new Error('Unterminated pack path');
      const name = idx.toString('utf8', p, end).replaceAll('\\', '/'); p = end + 1;
      entries.push({ name, size, offset }); offset += size;
    }
    if (p !== idxSize || offset !== fs.fstatSync(fd).size) throw new Error(`Pack size mismatch: ${file}`);
    return { flags, dependencies: dep, entries };
  } finally { fs.closeSync(fd); }
}

export function readEntry(file, entry) {
  const fd = fs.openSync(file, 'r');
  try { return readAt(fd, entry.size, entry.offset); } finally { fs.closeSync(fd); }
}

export function decodeLoc(b) {
  if (b.length < 14 || b.readUInt16LE(0) !== 0xfeff || b.toString('ascii', 2, 6) !== 'LOC\0' || b.readUInt32LE(6) !== 1) throw new Error('Invalid LOC header');
  const count = b.readUInt32LE(10), rows = [];
  let p = 14;
  const str = () => {
    const n = b.readUInt16LE(p); p += 2;
    if (p + n * 2 > b.length) throw new Error('Truncated LOC string');
    const s = b.toString('utf16le', p, p + n * 2); p += n * 2; return s;
  };
  for (let i = 0; i < count; i++) {
    const key = str(), text = str();
    if (p >= b.length || b[p] > 1) throw new Error('Invalid LOC flag');
    rows.push({ key, text, tooltip: b[p++] });
  }
  if (p !== b.length) throw new Error('LOC trailing bytes');
  return rows;
}

export function encodeLoc(rows) {
  const h = Buffer.alloc(14); h.writeUInt16LE(0xfeff); h.write('LOC', 2); h.writeUInt32LE(1, 6); h.writeUInt32LE(rows.length, 10);
  const chunks = [h];
  for (const row of rows) {
    for (const s of [row.key, row.text]) {
      if (typeof s !== 'string' || s.length > 65535 || s.includes('\0')) throw new Error('Invalid LOC string');
      const n = Buffer.alloc(2); n.writeUInt16LE(s.length); chunks.push(n, Buffer.from(s, 'utf16le'));
    }
    chunks.push(Buffer.from([row.tooltip ? 1 : 0]));
  }
  return Buffer.concat(chunks);
}

export function encodePack(files) {
  const sorted = [...files].sort((a, b) => a.name.localeCompare(b.name)), index = [];
  for (const f of sorted) { const n = Buffer.alloc(4); n.writeUInt32LE(f.data.length); index.push(n, Buffer.from(f.name.replaceAll('/', '\\') + '\0')); }
  const idx = Buffer.concat(index), h = Buffer.alloc(28);
  h.write('PFH4'); h.writeUInt32LE(3, 4); h.writeUInt32LE(sorted.length, 16); h.writeUInt32LE(idx.length, 20);
  return Buffer.concat([h, idx, ...sorted.map(f => f.data)]);
}
