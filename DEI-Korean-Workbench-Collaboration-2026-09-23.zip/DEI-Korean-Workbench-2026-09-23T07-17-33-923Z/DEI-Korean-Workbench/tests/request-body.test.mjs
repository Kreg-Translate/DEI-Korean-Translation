import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readJsonBody} from '../request-body.mjs';
import {acceptsWrite} from '../request-auth.mjs';

test('Already-open same-origin browser can save after server restart, external pages cannot',()=>{
  const address='http://127.0.0.1:3219',token='a'.repeat(48),old='b'.repeat(48);
  assert(acceptsWrite({'x-workbench-token':token},token,address));
  assert(acceptsWrite({'x-workbench-token':old,origin:address,'sec-fetch-site':'same-origin'},token,address));
  assert(!acceptsWrite({'x-workbench-token':old},token,address));
  assert(!acceptsWrite({'x-workbench-token':old,origin:'http://external.invalid','sec-fetch-site':'cross-site'},token,address));
  assert(!acceptsWrite({origin:address,'sec-fetch-site':'same-origin'},token,address));
});

test('Korean and supplementary Unicode survive every UTF-8 network chunk boundary',async()=>{
  const expected={text:'개선되었는데, 우리의 군사 전술과 장비 개혁이 거의 완료되었습니다. 🏛️',note:'태그 [[col:green]]와 %d를 보존합니다.\n다음 줄'};
  const bytes=Buffer.from(JSON.stringify(expected));
  for(let cut=1;cut<bytes.length;cut++){
    const chunks=(async function*(){yield bytes.subarray(0,cut);yield bytes.subarray(cut);})();
    assert.deepEqual(await readJsonBody(chunks),expected);
  }
  const oneByte=(async function*(){for(let i=0;i<bytes.length;i++)yield bytes.subarray(i,i+1);})();
  assert.deepEqual(await readJsonBody(oneByte),expected);
});
test('Request body size and invalid JSON are rejected explicitly',async()=>{
  await assert.rejects(()=>readJsonBody((async function*(){yield Buffer.from('"한글"');})(),5),e=>e.status===413);
  await assert.rejects(()=>readJsonBody((async function*(){yield Buffer.from('{broken');})()),e=>e.status===400);
});
