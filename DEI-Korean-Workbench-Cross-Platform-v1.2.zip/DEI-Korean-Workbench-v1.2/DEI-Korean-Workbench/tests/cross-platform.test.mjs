import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawnSync} from 'node:child_process';
import {resolvePackPath,readPackConfig} from '../config-paths.mjs';
import {ROOT,hash} from '../scan.mjs';

test('Mac home, Windows, and relative paths retain spaces and Unicode',()=>{
  assert.equal(resolvePackPath('~/Library/Application Support/Steam/test.pack',{root:'/tmp/app',home:'/Users/번역가',pathApi:path.posix}),'/Users/번역가/Library/Application Support/Steam/test.pack');
  assert.equal(resolvePackPath('mods/test.pack',{root:'/Users/번역가/작업 폴더',pathApi:path.posix}),'/Users/번역가/작업 폴더/mods/test.pack');
  assert.equal(resolvePackPath('D:/Steam Library/test.pack',{root:'C:\\app',pathApi:path.win32}),'D:\\Steam Library\\test.pack');
  assert.throws(()=>resolvePackPath('',{root:ROOT}));
});
test('Per-computer configuration overrides only named paths and leaves shared config untouched',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dei-config-'));
  const config={packs:[{label:'DEI Part 1',role:'source',path:'original.pack'},{label:'기본 번역',role:'base_ko',path:'base.pack'}]};
  fs.writeFileSync(path.join(dir,'config.json'),JSON.stringify(config));
  fs.writeFileSync(path.join(dir,'config.local.json'),'\ufeff'+JSON.stringify({paths:{'DEI Part 1':'새 폴더/source.pack'}}));
  const loaded=readPackConfig(dir);assert.equal(loaded.packs[0].path,path.join(dir,'새 폴더/source.pack'));assert.equal(loaded.packs[1].path,path.join(dir,'base.pack'));assert.deepEqual(JSON.parse(fs.readFileSync(path.join(dir,'config.json'),'utf8')),config);
});
test('Mac launcher files have UTF-8, LF, and system Bash-compatible syntax',()=>{
  for(const name of ['Start.command','Stop.command','runtime.sh']){
    const data=fs.readFileSync(path.join(ROOT,name));assert(data.toString().startsWith('#!/bin/bash\n'));assert(!data.includes(13));assert(!data.toString().includes('\ufffd'));
    if(process.platform!=='win32'){const r=spawnSync('/bin/bash',['-n',path.join(ROOT,name)],{encoding:'utf8'});assert.equal(r.status,0,r.stderr);}
  }
});
test('Portable launch, save, stop, restart, and backup work in a Unicode folder without source packs',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'dei 한글 작업실 '));
  for(const name of fs.readdirSync(ROOT).filter(name=>/\.(mjs|command|sh)$/.test(name)))fs.copyFileSync(path.join(ROOT,name),path.join(dir,name));
  // Copy each fixture file explicitly: Node 22's Windows recursive copy can
  // put files under a differently encoded Unicode destination directory.
  fs.mkdirSync(path.join(dir,'public'));
  for(const name of fs.readdirSync(path.join(ROOT,'public'))){
    const source=path.join(ROOT,'public',name),dest=path.join(dir,'public',name);
    fs.copyFileSync(source,dest);
    assert.deepEqual(fs.readFileSync(dest),fs.readFileSync(source));
  }
  fs.mkdirSync(path.join(dir,'data'));
  fs.copyFileSync(path.join(ROOT,'data/catalog.json'),path.join(dir,'data/catalog.json'));
  fs.writeFileSync(path.join(dir,'config.json'),JSON.stringify({packs:[{label:'Missing mod',path:'/no/such/mod.pack',role:'source'}]}));
  const env={...process.env,DEI_PORT:'3237',DEI_DATA_DIR:path.join(dir,'data'),DEI_NO_BROWSER:'1',DEI_NODE:process.execPath};
  const run=name=>process.platform==='darwin'?spawnSync('/bin/bash',[path.join(dir,name==='launch'?'Start.command':'Stop.command')],{env,cwd:os.tmpdir(),encoding:'utf8',timeout:20000}):spawnSync(process.execPath,[path.join(dir,name+'.mjs')],{env,cwd:os.tmpdir(),encoding:'utf8',timeout:20000});
  const api='http://127.0.0.1:3237';let token;
  const call=async(route,data)=>{const r=await fetch(api+route,data?{method:'POST',headers:{'Content-Type':'application/json','X-Workbench-Token':token,Connection:'close'},body:JSON.stringify(data)}:{headers:{Connection:'close'}});assert(r.ok,await r.clone().text());return r.json();};
  try{
    let r=run('launch');assert.equal(r.status,0,r.stderr||r.stdout);token=(await call('/api/summary')).token;
    const catalog=JSON.parse(fs.readFileSync(path.join(dir,'data/catalog.json'),'utf8'));
    const raw=catalog.entries.find(e=>e.initial==='untranslated'&&!e.sourceConflict&&e.source.trim());
    await call('/api/edit',{key:raw.key,text:'Mac ↔ Windows 저장 확인 🏛️',status:'draft',note:'줄바꿈\n메모',sourceHash:hash(raw.source),revision:0});
    const before=await call('/api/backup');assert.equal(before.edits[raw.key].text,'Mac ↔ Windows 저장 확인 🏛️');
    r=run('stop');assert.equal(r.status,0,r.stderr||r.stdout);
    r=run('launch');assert.equal(r.status,0,r.stderr||r.stdout);assert.deepEqual(await call('/api/backup'),before);
    const home=await fetch(api);assert(home.ok);
    assert.deepEqual(Buffer.from(await home.arrayBuffer()),fs.readFileSync(path.join(dir,'public/index.html')));
  }finally{run('stop');}
});
