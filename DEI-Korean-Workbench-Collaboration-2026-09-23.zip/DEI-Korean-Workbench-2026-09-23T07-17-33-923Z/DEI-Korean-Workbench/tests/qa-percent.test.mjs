import {test} from 'node:test';
import assert from 'node:assert/strict';
import {qa} from '../model.mjs';

test('Total War population effects permit Korean word order after escaped percent',()=>{
  for(const [en,ko] of [
    ['%+n%% 1st class population growth','1등급 시민 인구 성장 %+n%%'],
    ['%+n%% 1st and 2nd class population growth','1, 2등급 시민 인구 성장 %+n%%'],
    ['%+n%% 3rd and 4th Class','%+n%% 3, 4등급 시민'],
  ])assert.deepEqual(qa(en,ko),[]);
});

test('Missing or altered Total War numeric placeholders and percent signs are rejected',()=>{
  for(const [en,ko] of [
    ['%+n Public order','공공 질서'],
    ['%+n Public order','공공 질서 %n'],
    ['%-n Cost','비용 %+n'],
    ['%n Income','수입'],
    ['%+n%% Growth','성장 %+n'],
    ['%+n%% Growth','성장 %+n%'],
  ])assert(qa(en,ko).some(e=>e.level==='error'),`${en} / ${ko}`);
});

test('Printf, numbered, tags, and escaped newlines retain validation',()=>{
  const en='[[col:green]]Value %02d %1$s %1 {value}\\n[[/col]]';
  assert.deepEqual(qa(en,'[[col:green]]값 %02d %1$s %1 {value}\\n[[/col]]'),[]);
  assert(qa(en,'[[col:green]]값 %02d %1$s %1 {value}[[/col]]').some(e=>e.level==='error'));
});
