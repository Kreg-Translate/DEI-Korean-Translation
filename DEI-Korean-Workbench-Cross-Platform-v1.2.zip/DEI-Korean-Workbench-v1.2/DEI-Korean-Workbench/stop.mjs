try {
  const port=Number(process.env.DEI_PORT||3219);
  if(!Number.isInteger(port)||port<1||port>65535)throw Error('Invalid DEI_PORT.');
  const url=`http://127.0.0.1:${port}`;
  const info=await (await fetch(url+'/api/summary')).json();
  if(info.app!=='dei-korean-workbench')throw Error('The port belongs to another application.');
  const response=await fetch(url+'/api/shutdown',{method:'POST',headers:{'Content-Type':'application/json','X-Workbench-Token':info.token},body:'{}'});
  if(!response.ok)throw Error('Could not stop the workbench.');
  console.log('Workbench stopped. Saved translations are preserved.');
}catch(e){console.log(e.cause?.code==='ECONNREFUSED'?'Workbench is not running.':e.message);if(e.cause?.code!=='ECONNREFUSED')process.exitCode=1;}
