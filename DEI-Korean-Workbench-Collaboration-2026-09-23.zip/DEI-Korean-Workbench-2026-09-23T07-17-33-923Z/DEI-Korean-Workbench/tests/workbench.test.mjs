import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import http from 'node:http';
import {ROOT,hash} from '../scan.mjs';
import {encodeLoc,decodeLoc,encodePack,readPack,readEntry} from '../pack.mjs';
import {qa,effective,summary} from '../model.mjs';

test('PFH4 and LOC round-trip preserves Unicode, flags, and literal formatting',()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'dei-codec-'));
  const rows=[{key:'example_한글',text:'[[col:yellow]]보급 %d 🏛️[[/col]]\n두 번째 줄\\n',tooltip:1}];
  const loc=encodeLoc(rows);assert.deepEqual(decodeLoc(loc),rows);
  const file=path.join(tmp,'sample.pack');fs.writeFileSync(file,encodePack([{name:'text/db/test.loc',data:loc}]));
  const pack=readPack(file);assert.equal(pack.flags,3);assert.equal(pack.entries.length,1);
  assert.deepEqual(decodeLoc(readEntry(file,pack.entries[0])),rows);
  assert.throws(()=>decodeLoc(loc.subarray(0,loc.length-1)));
  const invalid=Buffer.from(loc);invalid.writeUInt32LE(10,10);assert.throws(()=>decodeLoc(invalid));
});

test('QA blocks broken placeholders but accepts valid Korean and warns about changed numbers',()=>{
  const source='[[col:green]]Supplies: %d[[/col]] 25%\\n';
  assert.equal(qa(source,'[[col:green]]보급품: %d[[/col]] 25%\\n').length,0);
  assert(qa(source,'보급품: 25%').some(x=>x.level==='error'));
  assert(qa(source,'[[col:green]]보급품: %d[[/col]] 30%\\n').some(x=>x.level==='warning'));
  assert(qa('Supplies','보급',[{en:'Supplies',ko:'보급품'}]).some(x=>x.level==='warning'));
});

test('Changed source is stale, and empty entries do not increase completion',()=>{
  const base={key:'x',source:'new',sourceHash:hash('new'),variants:[{text:'new'}],initial:'untranslated',category:'기타'};
  assert.equal(effective(base,{x:{text:'번역',sourceHash:hash('old'),status:'reviewed'}}).status,'stale');
  const data={entries:[base,{...base,key:'blank',initial:'blank'}],report:{}};
  const r=summary(data,{blank:{text:'new',sourceHash:hash('new'),status:'exempt'}});assert.equal(r.target,1);assert.equal(r.completed,0);
});

test('Real dataset and API: save, reload, conflicts, import atomicity, export, and origin guard',async()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'dei-api-')),port=3221;
  const child=spawn(process.execPath,['server.mjs'],{cwd:ROOT,env:{...process.env,DEI_PORT:String(port),DEI_DATA_DIR:tmp,DEI_EXPORT_DIR:path.join(tmp,'exports')},windowsHide:true,stdio:['ignore','pipe','pipe']});
  const endpoint=`http://127.0.0.1:${port}`;let token;
  async function call(route,b,headers={}){const r=await fetch(endpoint+route,b?{method:'POST',headers:{'content-type':'application/json','x-workbench-token':token,...headers},body:JSON.stringify(b)}:{headers});return{status:r.status,body:await r.json()};}
  try{
    await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Server startup timeout')),15000);child.stdout.on('data',b=>{if(b.toString().includes('http://')){clearTimeout(timer);resolve();}});child.once('error',reject);});
    const meta=(await call('/api/summary')).body;token=meta.token;assert.equal(meta.report.total,39754);assert.equal(meta.counts.untranslated,9124);
    const data=JSON.parse(fs.readFileSync(path.join(ROOT,'data/catalog.json'),'utf8'));
    const raw=data.entries.find(e=>e.initial==='untranslated'&&!e.sourceConflict&&e.source.length>10&&!/\[\[|%|\{|\\n/.test(e.source));
    const get=()=>call('/api/entry?key='+encodeURIComponent(raw.key));
    const e=(await get()).body;
    assert.equal((await call('/api/export-pack',{})).status,400);
    assert.equal((await call('/api/edit',{key:e.key,text:'테스트 번역',status:'draft',sourceHash:e.sourceHash,revision:0},{origin:'http://external.invalid'})).status,403);
    const edit={key:e.key,text:'테스트 번역',status:'draft',sourceHash:e.sourceHash,revision:0};
    assert.equal((await call('/api/edit',edit)).status,200);
    assert.equal((await get()).body.translation,'테스트 번역');assert.equal((await get()).body.status,'draft');
    assert.equal(JSON.parse(fs.readFileSync(path.join(tmp,'workspace.json'),'utf8')).edits[e.key].text,'테스트 번역');
    assert.equal((await call('/api/edit',edit)).status,409);
    assert.equal((await call('/api/edit',{...edit,revision:1,sourceHash:'changed'})).status,409);
    assert.equal((await call('/api/edit',{...edit,revision:1,status:'reviewed'})).status,200);
    const exported=await call('/api/export-pack',{});assert.equal(exported.status,200);assert.equal(exported.body.count,1);
    const file=path.join(tmp,'exports',exported.body.filename),pack=readPack(file),exportRows=decodeLoc(readEntry(file,pack.entries[0]));
    assert.equal(exportRows.length,1);assert.equal(exportRows[0].key,e.key);assert.equal(exportRows[0].text,'테스트 번역');
    const tagged=data.entries.find(e=>e.source.includes('[[col:')&&!e.sourceConflict);
    assert.equal((await call('/api/edit',{key:tagged.key,text:'서식 누락',status:'reviewed',sourceHash:tagged.sourceHash,revision:0})).status,400);
    assert.equal((await call('/api/import',{entries:[{key:tagged.key,text:'초안',sourceHash:tagged.sourceHash},{key:'DOES_NOT_EXIST',text:'bad'}]})).status,400);
    assert(!JSON.parse(fs.readFileSync(path.join(tmp,'workspace.json'),'utf8')).edits[tagged.key]);
    const conflict=data.entries.find(e=>e.sourceConflict),variant=conflict.variants.find(v=>v.text!==conflict.source);
    assert.equal((await call('/api/edit',{key:conflict.key,text:'선택 원문 검토',status:'draft',sourceHash:hash(variant.text),revision:0})).status,200);
    assert.equal((await call('/api/entry?key='+encodeURIComponent(conflict.key))).body.source,variant.text);
    assert.equal((await call('/api/glossary',{en:'Supplies',ko:'보급품'})).status,200);
    assert.equal((await call('/api/terms?q=Supplies')).body.glossary.length,1);
    assert.equal((await call('/api/backup')).body.entries.length,2);
    const wrongHost=await new Promise((resolve,reject)=>{const req=http.get(endpoint+'/api/summary',{headers:{Host:'evil.invalid'}},res=>{res.resume();res.on('end',()=>resolve(res.statusCode));});req.on('error',reject);});
    assert.equal(wrongHost,403);
  }finally{child.kill();await once(child,'exit');}
});
