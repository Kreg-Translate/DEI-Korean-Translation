import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { ROOT, scan, hash, category } from './scan.mjs';
import { effective, qa, summary, makeTerms, LABELS } from './model.mjs';
import { encodeLoc, encodePack, decodeLoc } from './pack.mjs';
import { readJsonBody as body } from './request-body.mjs';
import { acceptsWrite } from './request-auth.mjs';
import {makeBase,makeChanges,previewChanges,mergeChanges} from './collaboration.mjs';

const port=Number(process.env.DEI_PORT || 3219), address=`http://127.0.0.1:${port}`;
const dataDir=process.env.DEI_DATA_DIR || path.join(ROOT,'data');
fs.mkdirSync(dataDir,{recursive:true});
let dataset=fs.existsSync(path.join(ROOT,'data/catalog.json'))?JSON.parse(fs.readFileSync(path.join(ROOT,'data/catalog.json'),'utf8')):scan();
dataset.entries.forEach(e=>e.category=category(e.key));
const auditPath=path.join(ROOT,'data/translation-audit.json');
const auditKeys=fs.existsSync(auditPath)?JSON.parse(fs.readFileSync(auditPath,'utf8')).keys:{};
let byKey=new Map(dataset.entries.map(e=>[e.key,e])), terms=makeTerms({...dataset,entries:dataset.entries.filter(e=>!auditKeys[e.key])});
const statePath=path.join(dataDir,'workspace.json');
let state=fs.existsSync(statePath)?JSON.parse(fs.readFileSync(statePath,'utf8')):{version:1,edits:{},glossary:[]};
const token=crypto.randomBytes(24).toString('hex');
function persist(next) {
  fs.writeFileSync(statePath+'.tmp',JSON.stringify(next,null,2));
  if(fs.existsSync(statePath)) fs.copyFileSync(statePath,statePath+'.previous');
  fs.renameSync(statePath+'.tmp',statePath); state=next;
}
function fail(message,status=400){const e=new Error(message);e.status=status;throw e;}
function entry(key){const e=byKey.get(key);if(!e)fail('항목을 찾을 수 없습니다.',404);return {...effective(e,state.edits),audit:auditKeys[key]||null};}
function json(res,obj,status=200){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(obj));}
function validateEdit(raw,b) {
  if(!['draft','reviewed','exempt'].includes(b.status))fail('잘못된 상태입니다.');
  if(typeof b.text!=='string'||typeof (b.note||'')!=='string'||b.text.length>65535||(b.note||'').length>20000)fail('번역문 또는 메모가 너무 깁니다.');
  const variant=raw.variants.find(v=>hash(v.text)===b.sourceHash);
  if(!variant)fail('원문이 달라졌습니다. 원문을 다시 선택하세요.',409);
  const issues=qa(variant.text,b.text,state.glossary);
  if(b.status==='reviewed' && issues.some(x=>x.level==='error'))fail(issues.filter(x=>x.level==='error').map(x=>x.text).join(' '));
  if(b.status==='exempt' && b.text!==variant.text)fail('번역 불필요 항목은 원문 그대로 저장하세요.');
  const old=state.edits[raw.key];
  if((old?.revision||0)!==b.revision)fail('다른 창에서 수정되었습니다. 새로고침 후 다시 시도하세요.',409);
  const previous=old?{text:old.text,status:old.status,note:old.note,sourceHash:old.sourceHash,updatedAt:old.updatedAt}:null;
  return {text:b.text,status:b.status,note:b.note||'',sourceHash:b.sourceHash,revision:(old?.revision||0)+1,updatedAt:new Date().toISOString(),history:[...(old?.history||[]),...(previous?[previous]:[])].slice(-12)};
}
function references(e,q='') {
  const words=(q||e.source).toLowerCase().match(/[a-z]{3,}/g)||[];
  const ignore=new Set(['the','and','for','with','this','that','are','from','have','can','their','will','which','into','they','was','were']);
  const keys=[...new Set(words.filter(w=>!ignore.has(w)))].slice(0,20), rows=[];
  for(const raw of dataset.entries) {
    if(raw.key===e.key)continue;
    const x=effective(raw,state.edits);
    if(auditKeys[x.key] && x.status!=='reviewed')continue;
    if(!['existing','reviewed'].includes(x.status)||!x.translation)continue;
    const lower=x.source.toLowerCase();
    let score=keys.reduce((n,w)=>n+(lower.includes(w)?1:0),0);
    if(q && (x.translation.includes(q)||x.key.toLowerCase().includes(q.toLowerCase())))score+=10;
    if(!score)continue;
    // Normalize by document length so a long encyclopedia entry does not outrank a close sentence.
    const lengthRatio=Math.min(e.source.length,x.source.length)/Math.max(1,e.source.length,x.source.length);
    if(!q)score=score/Math.sqrt(Math.max(1,(lower.match(/[a-z]{3,}/g)||[]).length))*lengthRatio;
    score+=x.category===e.category?0.5:0;
    if(x.source===e.source)score+=100;
    rows.push({key:x.key,source:x.source,translation:x.translation,category:x.category,score,status:x.status,conflict:x.sourceConflict||x.translationConflict});
  }
  return rows.sort((a,b)=>b.score-a.score).slice(0,6);
}
const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'");
  try {
    if(req.headers.host!==`127.0.0.1:${port}`)fail('허용되지 않은 주소입니다.',403);
    if(req.headers.origin && req.headers.origin!==address)fail('다른 사이트의 접근을 차단했습니다.',403);
    const url=new URL(req.url,address),p=url.pathname;
    if(req.method==='POST') {
      if(!acceptsWrite(req.headers,token,address))fail('작업 화면을 새로고침하세요.',403);
      if(!(req.headers['content-type']||'').startsWith('application/json'))fail('JSON 입력이 필요합니다.',415);
      const b=await body(req);
      if(p==='/api/collaboration/export')return json(res,makeChanges(b.base,state,b.author));
      if(p==='/api/collaboration/preview')return json(res,previewChanges(b.packet,state,byKey));
      if(p==='/api/collaboration/merge'){
        const result=mergeChanges(b.packet,state,byKey,b.stateToken,b.choices);
        const folder=path.join(dataDir,'collaboration-backups',new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomBytes(4).toString('hex'));
        fs.mkdirSync(folder,{recursive:true});
        fs.writeFileSync(path.join(folder,'before-workspace.json'),JSON.stringify(state,null,2));
        fs.writeFileSync(path.join(folder,'received-changes.json'),JSON.stringify(b.packet,null,2));
        fs.writeFileSync(path.join(folder,'merge-decisions.json'),JSON.stringify({choices:b.choices,applied:result.applied,kept:result.kept},null,2));
        if(result.applied)persist(result.state);
        return json(res,{applied:result.applied,kept:result.kept,backupFolder:path.relative(dataDir,folder)});
      }
      if(p==='/api/shutdown'){json(res,{stopped:true});server.close();return;}
      if(p==='/api/edit') {
        const raw=byKey.get(b.key);if(!raw)fail('항목을 찾을 수 없습니다.',404);
        const edit=validateEdit(raw,b);persist({...state,edits:{...state.edits,[b.key]:edit}});
        return json(res,{entry:entry(b.key),issues:qa(entry(b.key).source,b.text,state.glossary)});
      }
      if(p==='/api/glossary') {
        if(typeof b.en!=='string'||typeof b.ko!=='string'||!b.en.trim()||!b.ko.trim()||b.en.length>150||b.ko.length>150)fail('원어와 번역어를 입력하세요 (150자 이내).');
        const next=state.glossary.filter(x=>x.en!==b.en.trim());
        if(!b.remove)next.push({en:b.en.trim(),ko:b.ko.trim(),note:String(b.note||'').slice(0,2000)});
        persist({...state,glossary:next});return json(res,{glossary:next});
      }
      if(p==='/api/import') {
        if(!Array.isArray(b.entries)||b.entries.length>50000)fail('entries 배열이 필요합니다.');
        const edits={...state.edits},seen=new Set();
        for(const row of b.entries){const raw=byKey.get(row.key);if(!raw||seen.has(row.key))fail(`알 수 없거나 중복된 키: ${row.key}`);seen.add(row.key);if(edits[row.key])fail(`기존 작업과 충돌합니다: ${row.key}. 항목 편집 화면에서 수정하세요.`);edits[row.key]=validateEdit(raw,{...row,status:'draft',revision:0});}
        persist({...state,edits});return json(res,{imported:seen.size});
      }
      if(p==='/api/export-pack') {
        const rows=[];
        for(const raw of dataset.entries){const e=effective(raw,state.edits);if(e.status!=='reviewed')continue;if(qa(e.source,e.translation,state.glossary).some(i=>i.level==='error'))fail(`검수 오류: ${e.key}`);rows.push({key:e.key,text:e.translation,tooltip:raw.variants.find(v=>hash(v.text)===e.sourceHash)?.tooltip??raw.tooltip});}
        if(!rows.length)fail('검수 완료 항목을 먼저 저장하세요.');
        const loc=encodeLoc(rows);if(JSON.stringify(decodeLoc(loc))!==JSON.stringify(rows))fail('내보내기 검증에 실패했습니다.');
        const pack=encodePack([{name:'text/db/!!!!!!_dei_korean_workbench.loc',data:loc}]);
        const folder=process.env.DEI_EXPORT_DIR || path.join(ROOT,'exports');fs.mkdirSync(folder,{recursive:true});
        const filename=`!!!!!!_dei_korean_workbench_${new Date().toISOString().replace(/[:.]/g,'-')}.pack`;
        fs.writeFileSync(path.join(folder,filename),pack,{flag:'wx'});
        fs.writeFileSync(path.join(folder,filename+'.json'),JSON.stringify({exportedAt:new Date().toISOString(),count:rows.length,keys:rows.map(r=>r.key),sha256:hash(pack),note:'검수 완료 번역만 포함한 추가 패치. 원본 모드와 두 한글패치가 필요합니다. 게임 적용과 로드 순서는 별도 확인.'},null,2));
        return json(res,{count:rows.length,filename,url:'/exports/'+filename});
      }
      if(p==='/api/rescan'){dataset=scan();byKey=new Map(dataset.entries.map(e=>[e.key,e]));terms=makeTerms({...dataset,entries:dataset.entries.filter(e=>!auditKeys[e.key])});return json(res,summary(dataset,state.edits));}
      fail('잘못된 요청입니다.',404);
    }
    if(req.method!=='GET')fail('허용되지 않는 요청입니다.',405);
    if(p==='/api/summary')return json(res,{...summary(dataset,state.edits),app:'dei-korean-workbench',token,labels:LABELS});
    if(p==='/api/entries') {
      const q=(url.searchParams.get('q')||'').toLowerCase(),status=url.searchParams.get('status'),cat=url.searchParams.get('category'),file=url.searchParams.get('file');
      const rows=[];
      for(const raw of dataset.entries){const e=effective(raw,state.edits);if(status==='conflicts'&&!(e.sourceConflict||e.translationConflict))continue;if(status&&status!=='all'&&status!=='conflicts'&&e.status!==status)continue;if(cat&&e.category!==cat)continue;if(file&&!e.variants.some(v=>v.file===file))continue;if(q&&![e.key,e.source,e.translation,...e.dei.map(v=>v.text),...e.base.map(v=>v.text)].join('\n').toLowerCase().includes(q))continue;rows.push({key:e.key,source:e.source.slice(0,170),translation:e.translation.slice(0,120),category:e.category,status:e.status,conflict:e.sourceConflict||e.translationConflict});}
      const offset=Math.max(0,Number(url.searchParams.get('offset'))||0);return json(res,{total:rows.length,rows:rows.slice(offset,offset+70)});
    }
    if(p==='/api/entry'){const e=entry(url.searchParams.get('key'));return json(res,{...e,variants:e.variants.map(v=>({...v,hash:hash(v.text)})),issues:[...(e.audit?[{level:'warning',text:'기존 DEI 번역 대응 점검: '+e.audit.reason+' 현재 저장한 번역과는 별도로, 기존 번역을 그대로 재사용하기 전에 확인하세요.'}]:[]),...qa(e.source,e.translation,state.glossary)],references:references(e),terms:state.glossary.filter(t=>e.source.toLowerCase().includes(t.en.toLowerCase()))});}
    if(p==='/api/references')return json(res,references(entry(url.searchParams.get('key')),url.searchParams.get('q')||''));
    if(p==='/api/terms'){const q=(url.searchParams.get('q')||'').toLowerCase();return json(res,{glossary:state.glossary,candidates:terms.filter(t=>(t.en+' '+t.ko).toLowerCase().includes(q)).slice(0,80),total:terms.length});}
    if(p==='/api/backup'){res.setHeader('Content-Disposition','attachment; filename="dei-workspace-backup.json"');return json(res,{...state,scannedAt:dataset.report.scannedAt,entries:Object.entries(state.edits).map(([key,e])=>({key,...e}))});}
    if(p==='/api/collaboration/base'){res.setHeader('Content-Disposition','attachment; filename="dei-shared-base.json"');return json(res,makeBase(state));}
    if(p==='/api/catalog-export'){res.setHeader('Content-Disposition','attachment; filename="dei-translation-catalog.json"');return json(res,{report:dataset.report,entries:dataset.entries.map(raw=>{const e=effective(raw,state.edits);return{key:e.key,category:e.category,source:e.source,sourceHash:e.sourceHash,text:e.translation,status:e.status,conflict:e.sourceConflict||e.translationConflict};})});}
    if(p==='/api/orphans')return json(res,dataset.orphan);
    let filename;
    if(p.startsWith('/exports/') && /^\/exports\/[!a-zA-Z0-9_.-]+\.pack$/.test(p)){filename=path.join(process.env.DEI_EXPORT_DIR || path.join(ROOT,'exports'),path.basename(p));res.setHeader('Content-Disposition',`attachment; filename="${path.basename(filename)}"`);}
    else {const allowed={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/favicon.svg':'favicon.svg'};if(!allowed[p])fail('페이지를 찾을 수 없습니다.',404);filename=path.join(ROOT,'public',allowed[p]);}
    const ext=path.extname(filename),mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'}[ext]||'application/octet-stream';
    res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store'});res.end(fs.readFileSync(filename));
  }catch(e){console.error(e.message);if(!res.headersSent)json(res,{error:e.message},e.status||500);else res.end();}
});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?`이미 실행 중이거나 포트가 사용 중입니다: ${address}`:e.message);process.exitCode=1;});
server.listen(port,'127.0.0.1',()=>console.log(`DEI Korean Workbench: ${address}`));
