@echo off
setlocal
cd /d "%~dp0"
node stop.mjs
pause
