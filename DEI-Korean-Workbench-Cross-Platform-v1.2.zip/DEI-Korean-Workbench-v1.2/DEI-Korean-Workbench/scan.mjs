import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readPack, readEntry, decodeLoc, encodeLoc } from './pack.mjs';
import {readPackConfig} from './config-paths.mjs';
export const ROOT = path.dirname(fileURLToPath(import.meta.url));
export const hasKorean = s => /[가-힣ㄱ-ㅎㅏ-ㅣ]/.test(s || '');
export const hash = s => crypto.createHash('sha256').update(s).digest('hex');
export function category(key) {
  if (key.startsWith('character_trait')) return '특성';
  if (key.startsWith('start_pos_faction')) return '세력';
  if (key.startsWith('start_pos_settlement') || key.startsWith('regions_') || key.startsWith('provinces_')) return '지역';
  if (key.startsWith('advice_')) return '도움말';
  if (key.startsWith('political_') || key.startsWith('culture_subculture_politics')) return '정치';
  if (key.startsWith('message_event') || key.startsWith('cdir_events')) return '이벤트';
  if (key.startsWith('naval_units_')) return '병종';
  const types = [ ['units_', '병종'], ['land_units_', '병종'], ['unit_', '병종'], ['building', '건물'], ['technology', '기술'], ['technologies', '기술'], ['faction', '세력'], ['diplom', '외교'], ['effect', '효과'], ['trait', '특성'], ['ancillar', '수행원'], ['agent', '인물'], ['character', '인물'], ['names_', '인명'], ['campaign', '캠페인'], ['event', '이벤트'], ['incident', '이벤트'], ['dilemma', '이벤트'], ['mission', '임무'], ['ui_', '인터페이스'], ['encyclop', '백과사전'] ];
  return types.find(([p]) => key.startsWith(p))?.[1] || '기타';
}
export function scan() {
  const config = readPackConfig(ROOT);
  const missing=config.packs.filter(pack=>!fs.existsSync(pack.path));
  if(missing.length)throw Error('모드 파일을 찾을 수 없습니다. 동봉된 원문으로 번역하려면 다시 읽기가 필요하지 않습니다. 모드를 갱신하려면 config.local.json의 경로를 확인하세요: '+missing.map(p=>p.label+' ('+p.path+')').join(', '));
  const maps = { source: new Map(), dei_ko: new Map(), base_ko: new Map() }, inventory = [];
  for (const pack of config.packs) {
    const info = readPack(pack.path), st = fs.statSync(pack.path), locFiles = [], digest = crypto.createHash('sha256');
    for (const entry of info.entries.filter(e => e.name.toLowerCase().endsWith('.loc'))) {
      const buf = readEntry(pack.path, entry), rows = decodeLoc(buf);
      if (!encodeLoc(rows).equals(buf)) throw new Error(`LOC round-trip mismatch: ${entry.name}`);
      digest.update(entry.name); digest.update(buf);
      locFiles.push({ name: entry.name, rows: rows.length, bytes: buf.length });
      for (const r of rows) {
        if (!r.key) continue;
        const v = { ...r, pack: pack.label, file: entry.name };
        const group = maps[pack.role].get(r.key) || []; group.push(v); maps[pack.role].set(r.key, group);
      }
    }
    inventory.push({ ...pack, bytes: st.size, mtime: st.mtime.toISOString(), files: info.entries.length, locFiles, locSha256: digest.digest('hex') });
    console.log(`${pack.label}: ${locFiles.length} LOC / ${locFiles.reduce((n,x)=>n+x.rows,0)} rows`);
  }
  const entries = [];
  for (const [key, variants] of maps.source) {
    const unique = [...new Set(variants.map(v => v.text))];
    // Selection here is a stable display default, not a claim about the game's load order.
    const src = variants[0], dei = maps.dei_ko.get(key) || [], base = maps.base_ko.get(key) || [];
    const ko = dei.find(v => hasKorean(v.text)), fallback = base.find(v => hasKorean(v.text));
    const blank = !src.text.trim();
    entries.push({ key, category: category(key), source: src.text, sourceHash: hash(src.text), tooltip: src.tooltip, variants, dei, base,
      initial: blank ? 'blank' : ko ? 'existing' : fallback ? 'base' : 'untranslated',
      candidate: ko?.text || fallback?.text || '',
      sourceConflict: unique.length > 1,
      translationConflict: new Set(dei.map(v=>v.text)).size > 1,
      latinOnly: !ko && !fallback && dei.some(v => v.text.trim()) });
  }
  entries.sort((a,b)=>a.key.localeCompare(b.key));
  const orphan = [...maps.dei_ko.entries()].filter(([key])=>!maps.source.has(key)).map(([key,variants])=>({key,variants}));
  const counts = {};
  for (const e of entries) counts[e.initial] = (counts[e.initial] || 0) + 1;
  const report = { scannedAt: new Date().toISOString(), total: entries.length, counts, sourceConflicts: entries.filter(e=>e.sourceConflict).length, translationConflicts: entries.filter(e=>e.translationConflict).length, orphanCount: orphan.length, inventory };
  const dataset = { report, entries, orphan };
  fs.mkdirSync(path.join(ROOT,'data'),{recursive:true});
  const target = path.join(ROOT,'data/catalog.json');
  fs.writeFileSync(target+'.tmp',JSON.stringify(dataset)); fs.renameSync(target+'.tmp',target);
  fs.writeFileSync(path.join(ROOT,'data/scan-report.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify({...report,inventory:undefined},null,2));
  return dataset;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) scan();
