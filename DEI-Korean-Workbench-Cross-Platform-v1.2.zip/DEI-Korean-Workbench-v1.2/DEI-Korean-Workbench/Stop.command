#!/bin/bash
source "$(dirname -- "$0")/runtime.sh"
"$NODE_BIN" "$WORKBENCH_ROOT/stop.mjs" || workbench_error '종료하지 못했습니다. 실행 중인 작업실을 확인하세요.'
